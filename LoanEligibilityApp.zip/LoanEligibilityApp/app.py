import pymysql
from flask import Flask
from flask import render_template, url_for, request, redirect

from flask_sqlalchemy import SQLAlchemy

import pickle
from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np

app = Flask(__name__)
pymysql.install_as_MySQLdb()

app.config['DEBUG'] = True
app.config['ENV'] = 'development'
app.config['FLASK_ENV'] = 'development'
app.config['SECRET_KEY'] = 'ItShouldBeALongStringOfRandomCharacters'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:admin123@localhost:3306/loancheck_user_mngmt'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

app.app_context().push()


class Users(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(128))
    password = db.Column(db.String(128))


db.create_all()


@app.route('/')
def home_page():
    return render_template("home.html")


@app.route('/register.html', methods=['GET', 'POST'])
def new_user_reg():
    if request.method == 'GET':
        return render_template("register.html")

    elif request.method == 'POST':
        user_exits = \
            Users.query.filter(
                Users.username == request.form.get('username')).count()
        if user_exits:
            return render_template('register.html', error_text='Username already exists! Please proceed to Login')
        else:
            new_user = Users(username=request.form.get('username'),
                             password=request.form.get('password'))
            db.session.add(new_user)
            db.session.commit()
            return render_template('register.html', error_text='New user created! Please proceed to Login')


@app.route('/login.html', methods=['GET', 'POST'])
def login_user():
    if request.method == 'GET':
        return render_template("login.html")

    elif request.method == 'POST':
        user_exits_1 = \
            Users.query.filter(
                Users.username == request.form.get('username')).count()
        if user_exits_1:
            user_data = Users.query.all()
            for user in user_data:
                if user.username == request.form.get('username'):
                    if user.password == request.form.get('password'):
                        return render_template('predict.html')
                    else:
                        return render_template('login.html', error_text='Invalid Password! Please try again')
        else:
            return render_template('login.html', error_text='Invalid Username! Please proceed to Signup')


model = pickle.load(open(r'model.pkl', 'rb'))


@app.route('/predict', methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    int_features = [int(x) for x in request.form.values()]
    final_features = [np.array(int_features)]
    # scaled_final_features = ss.fit_transform(final_features)
    prediction = model.predict(final_features)

    output = round(prediction[0], 2)

    if output == 0:
        result = "Not Approved!"
    else:
        result = "Approved!"

    return render_template('predict.html', prediction_text='The Loan is {}'.format(result))


if __name__ == "__main__":
    app.run(debug=True)
